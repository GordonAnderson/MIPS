/*
 * serial.c
 *
 * This file contains the code for the serial IO hardware including the ring buffer
 * code and the serial command processor.
 *
 * Developed by: Gordon Anderson
 */
#include "Serial.h"
#include "Errors.h"
#include "DIO.h"
#include "Table.h"

Serial_ *serial = &SerialUSB;
//HardwareSerial *serial = &Serial;

#define MaxToken 10

char Token[MaxToken];
char Sarg1[MaxToken];
char Sarg2[MaxToken];
unsigned char Tptr;

int ErrorCode = 0;   // Last communication error that was logged

Ring_Buffer  RB;     // Receive ring buffer

Commands  CmdArray[] = 	{
  // General commands
  {"GVER", CMDstr, 0, (char *)Version},	// Report version
  {"GERR", CMDint, 0, (char *)&ErrorCode},    // Report the last error code
  //  {"SAVE", CMDfunction, 0, SAVEparms},	      // Save all settings
  //  {"GCHAN", CMDfunctionStr, 1, GetNumChans},  // Report number for the selected system

  // HV power supply commands
  //  {"SDCB", CMDfunction, 2, HVPSset},		   // Set HV value
  //  {"GDCB", CMDfunction, 1, HVPSread},	   // Get HV value requested
  //  {"GDCBV", CMDfunction, 1, HVPSreadV},	   // Get HV actual voltage value
  //  {"GDCBI", CMDfunction, 1, HVPSreadI},	   // Get HV output current value
  //  {"SDCBOF", CMDfunction, 2, HVPSsetFloat}, // Set float voltage for selected board
  //  {"GDCBOF", CMDfunction, 1, HVPSreadFloat}, // Read float voltage for selected board
  //  {"SDCG", CMDfunctionStr, 1, HVPSsetGuard},	 // Turn guard supplies ON/OFF
  //  {"GDCG", CMDfunction, 0, HVPSreadGuard},  // Read gaurd supplies status ON/OFF/LOW
  // LOW = ON with low battery warning
  // RF generator commands
  //  {"SRFFRQ", CMDfunction, 2, RFfreq},		 // Set RF frequency
  //  {"SRFAUTO", CMDfunction, 2, RFvoltage},	 // Set RF output voltage
  //  {"SRFDRV", CMDfunction, 2, RFdrive},		 // Set RF drive level
  //  {"GRFFRQ", CMDfunction, 1, RFfreqReport},	 // Report RF frequency
  //  {"GRFPPV", CMDfunction, 1, RFvoltageReport}, // Report RF output voltage
  //  {"GRFDRV", CMDfunction, 1, RFdriveReport}, // Report RF drive level
  // DIO commands
  {"SDIO", CMDfunctionStr, 2, (char *)SDIO_Serial},	 // Set DIO output bit
  {"GDIO", CMDfunctionStr, 1, (char *)GDIO_Serial},	 // Get DIO output bit
  // Source controller commands
  //  {"SHTRTMP", CMDfunction, 1, SourceSetTemp}, // Set inlet temp
  //  {"GHTRTMP", CMDint, 0, (void *)&SrcSetpoint.Value}, // Set inlet temp readback
  //  {"GHTRTC", CMDfunction, 0, SourceReadTemp}, // Report inlet temp
  //  {"SPHV", CMDfunction, 1, SourceSetPosHV},  // Set positive HV
  //  {"GPHV", CMDint, 0, (void *)&SrcPosHV.Value}, // Read positive HV, setpoint
  //  {"GPHVV", CMDfunction, 0, SourceReadPosHV}, // Read positive HV, actual
  //  {"SNHV", CMDfunction, 1, SourceSetNegHV},  // Set negative HV
  //  {"GNHV", CMDint, 0, (void *)&SrcNegHV.Value}, // Read negative HV, setpoint
  //  {"GNHVV", CMDfunction, 0, SourceReadNegHV}, // Read negative HV
  //  {"SHTRGAIN", CMDfunction, 1, SourceLoopGain}, // Set loop gain
  //  {"GHTRGAIN", CMDint, 1, (void *)&SrcGain.Value}, // Set loop gain readback
  //  {"SHTR", CMDfunctionStr, 1, SourceLoopStatus}, // Set loop status ON/OFF
// Table commands
  {"STBLDAT", CMDfunction, 0, (char *)ParseTableCommand}, // Read the HVPS voltage table
  {"STBLCLK", CMDfunctionStr, 1, (char *)SetTableCLK},	  // Clock mode, EXT or INT
  {"STBLTRG", CMDfunctionStr, 1, (char *)SetTableTRG},	  // Trigger mode, EXT or SW
  {"TBLABRT", CMDfunction, 0, (char *)SetTableAbort},	  // Abort table operation
  {"SMOD", CMDfunctionStr, 1, (char *)SetTableMode},	  // Set the table mode
  {"TBLSTRT", CMDfunction, 0, (char *)SWTableTrg},	  // Set the software trigger
  // End of table marker
  {0},
};


// Generic get number of channels function, calls the proper routine based on parameter entered.
// RF = Number of RF channels
// DCB = number of DC bias channels
/*
void GetNumChans(char *cmd)
{
  if (strcmp(cmd, "RF") == 0) RFnumber();
  else if (strcmp(cmd, "DCB") == 0) HVPSnumber();
  else if (strcmp(cmd, "DIO") == 0) DIOnumber();
  else
  {
    SetErrorCode(ERR_BADARG);
    SendNAK;
    return;
  }
}
*/

void SerialInit(void)
{
  //  Serial.begin(9600);
  serial->begin(0);
  serial->println("Initializing....");
  RB_Init(&RB);
}

// This function builds a token string from the characters passed.
void Char2Token(char ch)
{
  Token[Tptr++] = ch;
  if (Tptr >= MaxToken) Tptr = MaxToken - 1;
}

// This function reads the serial input ring buffer and returns a pointer to a ascii token.
// Tokens are comma delimited. Commands strings end with a semicolon or a \n.
// The returned token pointer points to a standard C null terminated string.
// This function does not block. If there is nothing in the input buffer null is returned.
char *GetToken(bool ReturnComma)
{
  unsigned char ch;

  // Exit if the input buffer is empty
  ch = RB_Next(&RB);
  if (ch == 0xFF) return NULL;
  if (Tptr >= MaxToken) Tptr = MaxToken - 1;

  if ((ch == '\n') || (ch == ';') || (ch == ':') || (ch == ',') || (ch == ']') || (ch == '['))
  {
    if (Tptr != 0) ch = 0;
    else
    {
      Char2Token(RB_Get(&RB));
      ch = 0;
    }
  }
  else RB_Get(&RB);
  // Place the character in the input buffer and advance pointer
  Char2Token(ch);
  if (ch == 0)
  {
    Tptr = 0;
    if ((Token[0] == ',') && !ReturnComma) return NULL;
    return Token;
  }
  return NULL;
}

void ExecuteCommand(Commands *cmd, int arg1, int arg2, char *args1, char *args2)
{
  switch (cmd->Type)
  {
    case CMDstr:
      SendACK;
      serial->write(cmd->pointers.charPtr);
      serial->write("\n");
      break;
    case CMDint:
      // arg1 is a pointer to an int value to send out the serial port
      SendACK;
      sprintf(Token, "%d\n", *(cmd->pointers.intPtr));
      serial->write(Token);
      break;
    case CMDfunction:
      if (cmd->NumArgs == 0) cmd->pointers.funcVoid();
      if (cmd->NumArgs == 1) cmd->pointers.func1int(arg1);
      if (cmd->NumArgs == 2) cmd->pointers.func2int(arg1, arg2);
      break;
    case CMDfunctionStr:
      if (cmd->NumArgs == 0) cmd->pointers.funcVoid();
      if (cmd->NumArgs == 1) cmd->pointers.func1str(args1);
      if (cmd->NumArgs == 2) cmd->pointers.func2str(args1, args2);
      break;
    default:
      SendNAK;
      break;
  }
}

// This function processes serial commands.
void ProcessCommand(void)
{
  char *Token;
  int i;
  static int arg1, arg2;
  static enum PCstates state;
  static int CmdNum;

  Token = GetToken(false);
  if (Token == NULL) return;
  if (Token[0] == 0) return;
  switch (state)
  {
    case PCcmd:
      if (strcmp(Token, ";") == 0) break;
      if (strcmp(Token, "\n") == 0) break;
      CmdNum = -1;
      // Look for command in command table
      for (i = 0; CmdArray[i].Cmd != 0; i++) if (strcmp(Token, CmdArray[i].Cmd) == 0) {
          CmdNum = i;
          break;
        }
      if (CmdNum == -1)
      {
        SetErrorCode(ERR_BADCMD);
        SendNAK;
        break;
      }
      if (CmdArray[i].NumArgs > 0) state = PCarg1;
      else state = PCend;
      break;
    case PCarg1:
      sscanf(Token, "%d", &arg1);
      sscanf(Token, "%s", Sarg1);
      if (CmdArray[CmdNum].NumArgs > 1) state = PCarg2;
      else state = PCend;
      break;
    case PCarg2:
      sscanf(Token, "%d", &arg2);
      sscanf(Token, "%s", Sarg2);
      state = PCend;
      break;
    case PCend:
      if ((strcmp(Token, "\n") != 0) && (strcmp(Token, ";") != 0))
      {
        state = PCcmd;
        SendNAK;
        break;
      }
      i = CmdNum;
      CmdNum = -1;
      state = PCcmd;
      ExecuteCommand(&CmdArray[i], arg1, arg2, Sarg1, Sarg2);
      break;
    default:
      state = PCcmd;
      break;
  }
}

void RB_Init(Ring_Buffer *rb)
{
  rb->Head = 0;
  rb->Tail = 0;
  rb->Count = 0;
}

char RB_Size(Ring_Buffer *rb)
{
  return (rb->Count);
}

// Put character in ring buffer, return 0xFF if buffer is full and can't take a character.
// Return 0 if character is processed.
char RB_Put(Ring_Buffer *rb, char ch)
{
  serial->write(ch);
  if (rb->Count >= RB_BUF_SIZE) return (0xFF);
  rb->Buffer[rb->Tail] = ch;
  if (rb->Tail++ >= RB_BUF_SIZE - 1) rb->Tail = 0;
  rb->Count++;
  return (0);
}

// Get character from ring buffer, return NULL if empty.
char RB_Get(Ring_Buffer *rb)
{
  char ch;

  if (rb->Count == 0) return (0xFF);
  ch = rb->Buffer[rb->Head];
  if (rb->Head++ >= RB_BUF_SIZE - 1) rb->Head = 0;
  rb->Count--;
  // Map \r to \n
  if (ch == '\r') ch = '\n';
  return (ch);
}

// Return the next character in the ring buffer but do not remove it, return NULL if empty.
char RB_Next(Ring_Buffer *rb)
{
  char ch;

  if (rb->Count == 0) return (0xFF);
  ch = rb->Buffer[rb->Head];
  if (ch == '\r') ch = '\n';
  return (ch);
}



