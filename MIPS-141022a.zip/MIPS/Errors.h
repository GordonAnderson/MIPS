//
//  Errors.h
//  AMPS
//
//  Created by Gordon Anderson on 9/7/14.
//
// This fine defines all the error codes that can be set by the AMPS system.
// These error codes are defined when a serial command is received and
// can not be processed for some reason. Olny the last error is saved in the
// variable ErrorCode. The controlling computer and issue the GERR command to
// Read the error code. The error code is never cleared, that last error is
// always avalible.
//
#ifndef AMPS_Errors_h
#define AMPS_Errors_h

extern int ErrorCode;

#define SetErrorCode(x) ErrorCode=x

// List of error codes and there descriptions

#define ERR_BADCMD                  1       // invalid command
#define ERR_BADARG                  2       // invalid argument
#define ERR_LOCALREADY              3       // System already in LOC mode
#define ERR_TBLALREADY              4       // System already in TBL mode
#define ERR_NOTBLLOADED             5       // No tables have been loaded
#define ERR_NOTBLMODE               6       // System is not in table mode
#define ERR_TBLNOTREADY             7       // Table not ready
#define ERR_TOKENTIMEOUT            8       // Timed out waiting for token
#define ERR_EXPECTEDCOLON           9       // Expected to see a :
#define ERR_TBLTOOBIG               10      // Table too big!
#define ERR_CHLOWORBRD              11      // Channel number too low or board not present
#define ERR_CHHIORBRD               12      // Channel number too high or board not present
#define ERR_CHHIGH                  13      // Requested channel number too high
#define ERR_BRDLOWORBRD             14      // Board number too low or board not present
#define ERR_BRDHIORBRD              15      // Board number too high or board not present
#define ERR_BRDHIGH                 16      // Board number too high
#define ERR_BRDNOTSUPPORT           17      // Command not support on this board rev
#define ERR_BADBAUD                 18      // Invalid baud rate requsted
#define ERR_EXPECTEDCOMMA           19      // Expected comma
#define ERR_NESTINGTOODEEP          20      // Table nesting too deep
#define ERR_MISSINGOPENBRACKET      21      // Table ] without coresponding [
#define ERR_INVALIDCHAN             22      // Invalid channel request
#define ERR_DIOHARDWARENOTPRESENT   23      // DIO hardware not found
#define ERR_TEMPRANGE               24      // Temp range error
#define ERR_ESIHVOUTOFRANGE         25      // ESI HV out of range
#define ERR_TEMPCONTROLLOOPGAIN     26      // Temp control loop gain range error
#define ERR_NOTLOCMODE              27      // System is not in local mode

#endif

