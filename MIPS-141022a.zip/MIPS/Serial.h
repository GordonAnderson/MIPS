/*
 * Serial.h
 *
 * Created: 10/16/2014
 *  Author: Gordon Anderson
 */
#ifndef SERIAL_H_
#define SERIAL_H_

#include <Arduino.h>

#if defined(__SAM3X8E__)
#undef __FlashStringHelper::F(string_literal)
#define F(string_literal) string_literal
#endif


extern Serial_ *serial;
//extern HardwareSerial *serial;

// Ring buffer size
#define RB_BUF_SIZE		1024

#define SendNAK serial->write("\x15?\n")
#define SendACK serial->write("\x06\n")
#define SendERR serial->write("\x15?\n")
#define SendBSY serial->write("\x15?\n")

// The serial receiver uses Xon and Xoff to control input data from the source
#define XON   0x11
#define XOFF  0x13
#define EOF   0x1A
#define ACK   0x06
#define NAK   0x15

typedef struct
{
  char  Buffer[RB_BUF_SIZE];
  unsigned char  Tail;
  unsigned char  Head;
  unsigned char  Count;
} Ring_Buffer;

enum CmdTypes
{
  CMDstr,		        // Sends a string
  CMDint,			// Sends an int
  CMDfunction,		        // Calls a function with 0,1,or 2 int args
  CMDfunctionStr,		// Calls a function with pointer to str arg
  CMDna
};

enum PCstates
{
  PCcmd,			// Looking for a command token
  PCarg1,			// Looking for int arg1
  PCarg2,			// Looking for int arg2
  PCargStr,			// Looking for string arg
  PCend,
  PCna
};

union functions
{
  char *charPtr;
  int  *intPtr;
  void (*funcVoid)();
  void (*func1int)(int);
  void (*func2int)(int, int);
  void (*func1str)(char *);
  void (*func2str)(char *, char *);
};

typedef struct
{
  const char  		*Cmd;
  enum	CmdTypes	Type;
  int   		NumArgs;
  union functions pointers;
} Commands;

extern Ring_Buffer  RB;
extern char Version[];

// Macros
#define PutCh(ch)  RB_Put(&RB,ch)

// Function prototypes
void SerialInit(void);
char *GetToken(bool ReturnComma);
void  ProcessCommand(void);
void RB_Init(Ring_Buffer *);
char RB_Size(Ring_Buffer *);
char RB_Put(Ring_Buffer *, char);
char RB_Get(Ring_Buffer *);
char RB_Next(Ring_Buffer *);


#endif /* SERIAL_H_ */
