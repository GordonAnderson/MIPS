#ifndef Twave_h
#define Twave_h

// Prototypes
void SetPulseVoltage(void);
void SetVelocity(void);
void SetSequence(void);
void SetRestingVoltage(void);
void SetGuard1(void);
void SetGuard2(void);
void Twave_init(void);
void Twave_loop(void);


#endif

