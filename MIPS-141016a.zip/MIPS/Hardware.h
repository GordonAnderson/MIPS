//
// Hardware definitions for the MIPS controller
//
#ifndef Hardware_h
#define Hardware_h

// These are the pins used for the DUE hardware SPI
#define _sclk 76
#define _miso 74
#define _mosi 75
#define _cs 4
#define _rst 33
#define _dc 34

// microSD chip select pin
#define _sdcs 10

// Rotary encoder hardware pins and LED pins
#define PB_RED       31
#define PB_GREEN     24
#define PB_BLUE      23
#define PB_PHASE_A   29
#define PB_PHASE_B   30
#define PB           32

#define PB_GREEN_ON   digitalWrite(PB_GREEN,LOW)
#define PB_GREEN_OFF  digitalWrite(PB_GREEN,HIGH)
#define PB_RED_ON     digitalWrite(PB_RED,LOW)
#define PB_RED_OFF    digitalWrite(PB_RED,HIGH)
#define PB_BLUE_ON    digitalWrite(PB_BLUE,LOW)
#define PB_BLUE_OFF   digitalWrite(PB_BLUE,HIGH)

// Red LED on the PC board
#define RED_LED      19
#define RED_LED_ON    digitalWrite(RED_LED,LOW)
#define RED_LED_OFF   digitalWrite(RED_LED,HIGH)

// Misc signals
#define LDAC          11
#define ADDR0         25
#define ADDR1         26
#define ADDR2         27
#define SPI_CS        52
#define SCL           45    // Shift register clear
#define BRDSEL        47
#define TWI_SCL       21
#define TWI_SDA       20

#define  ENA_BRD_A    digitalWrite(BRDSEL,HIGH)
#define  ENA_BRD_B    digitalWrite(BRDSEL,LOW)

// Digitial input pins
#define  DI0          22
#define  DI1          12
#define  DI2          50
#define  DI3          51
#define  DI4          53
#define  DI5          28
#define  DI6          46
#define  DI7          17

#endif

